package com.github.newscalculator.screens.editvaluedialog

enum class TextInputType {
    OXYGEN,
    TEMPERATURE,
    COMMON
}